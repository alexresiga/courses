//
//  Tests.hpp
//  test
//
//  Created by Alex Resiga on 19/04/2018.
//  Copyright © 2018 Alex Resiga. All rights reserved.
//

#pragma once


class Tests
{
public:
    static void testRepo();
    static void testController();
};
