#include "document.h"

Document::Document()
{

}
